import React, { useState, useMemo, useRef, useEffect } from "react";

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

import { FaDollarSign, FaBox, FaChevronDown } from "react-icons/fa";

export default function Dashboard() {
  // ===========================
  // ROLE LOGIN
  // ===========================

  const role = localStorage.getItem("role") || "owner";
  const nama = localStorage.getItem("nama") || "Admin Hebepku";

  // ===========================
  // FILTER
  // ===========================

  const [selectedRegion, setSelectedRegion] = useState("ALL");
  const [selectedBrands, setSelectedBrands] = useState([]);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  // ===========================
  // DATA
  // ===========================

  const [salesData, setSalesData] = useState([]);
  const [brands, setBrands] = useState([]);
  const [summary, setSummary] = useState({});
  const [chartData, setChartData] = useState([]);

  const [isBrandOpen, setIsBrandOpen] = useState(false);

  const brandRef = useRef(null);

  // ===========================
  // GET DETAIL PENJUALAN
  // ===========================

  useEffect(() => {
    fetch("http://localhost:5000/api/dashboard/detail")
      .then((res) => res.json())
      .then((result) => {
        if (result.success) {
          setSalesData(result.data);
        }
      })
      .catch(console.log);
  }, []);

  // ===========================
  // GET BRAND
  // ===========================

  useEffect(() => {
    fetch("http://localhost:5000/api/brand")
      .then((res) => res.json())
      .then((result) => {
        if (result.success) {
          setBrands(result.data);
        }
      })
      .catch(console.log);
  }, []);

  // ===========================
  // GET SUMMARY
  // ===========================

  useEffect(() => {
    fetch("http://localhost:5000/api/dashboard/summary")
      .then((res) => res.json())
      .then((result) => {
        if (result.success) {
          setSummary(result.summary);
        }
      })
      .catch(console.log);
  }, []);

  // ===========================
  // GET CHART
  // ===========================

  useEffect(() => {
    fetch("http://localhost:5000/api/dashboard/chart")
      .then((res) => res.json())
      .then((result) => {
        if (result.success) {
          setChartData(
            result.data.map((item) => ({
              bulan: item.bulan,

              total_penjualan: Number(item.total_penjualan),
            })),
          );
        }
      })
      .catch(console.log);
  }, []);

  // ===========================
  // LIST BRAND
  // ===========================

  const availableBrands = [
    ...new Set(salesData.map((item) => item.nama_brand)),
  ];

  // ===========================
  // FILTER DATA
  // ===========================

  const filteredData = useMemo(() => {
    return salesData.filter((item) => {
      const wilayah =
        selectedRegion === "ALL" || item.nama_wilayah === selectedRegion;

      const brand =
        selectedBrands.length === 0 || selectedBrands.includes(item.nama_brand);

      const tanggal = item.tanggal_penjualan.substring(0, 10);

      const date =
        (!startDate || tanggal >= startDate) &&
        (!endDate || tanggal <= endDate);

      return wilayah && brand && date;
    });
  }, [salesData, selectedRegion, selectedBrands, startDate, endDate]);

  // ===========================
  // FILTER CHART
  // ===========================

  const filteredChartData = useMemo(() => {
    const hasil = [];

    filteredData.forEach((item) => {
      const bulan = item.tanggal_penjualan.substring(0, 7);

      const cek = hasil.find((x) => x.bulan === bulan);

      if (cek) {
        cek.total_penjualan += Number(item.total);
      } else {
        hasil.push({
          bulan,

          total_penjualan: Number(item.total),
        });
      }
    });

    return hasil;
  }, [filteredData]);

  // ===========================
  // TOTAL
  // ===========================

  const totalSales = filteredData.reduce(
    (sum, item) => sum + Number(item.total),

    0,
  );

  const totalQty = filteredData.reduce(
    (sum, item) => sum + Number(item.jumlah),

    0,
  );

  // ===========================
  // FORMAT RUPIAH
  // ===========================

  const formatRupiah = (angka) => {
    return "Rp " + Number(angka).toLocaleString("id-ID");
  };

  // ===========================
  // BRAND CHECKBOX
  // ===========================

  const handleBrandToggle = (brand) => {
    if (selectedBrands.includes(brand)) {
      setSelectedBrands(selectedBrands.filter((b) => b !== brand));
    } else {
      setSelectedBrands([...selectedBrands, brand]);
    }
  };

  // ===========================
  // CLOSE DROPDOWN
  // ===========================

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (brandRef.current && !brandRef.current.contains(event.target)) {
        setIsBrandOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div className="p-8 bg-gray-50 min-h-screen">
      {/* ================= HEADER ================= */}

      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">
            Dashboard {role === "owner" ? "Owner" : "Leader"}
          </h1>

          <p className="text-gray-500 mt-2">
            Selamat datang,
            <span className="font-semibold"> {nama}</span>
          </p>
        </div>
      </div>

      {/* ================= FILTER ================= */}

      <div className="bg-white rounded-xl shadow p-5 mb-6">
        <div className="flex flex-wrap gap-4">
          <select
            value={selectedRegion}
            onChange={(e) => setSelectedRegion(e.target.value)}
            className="border rounded-lg px-4 py-2"
          >
            <option value="ALL">Semua Wilayah</option>

            {[...new Set(salesData.map((item) => item.nama_wilayah))].map(
              (wilayah) => (
                <option key={wilayah} value={wilayah}>
                  {wilayah}
                </option>
              ),
            )}
          </select>

          <div className="relative" ref={brandRef}>
            <button
              className="border rounded-lg px-4 py-2 flex items-center gap-2"
              onClick={() => setIsBrandOpen(!isBrandOpen)}
            >
              Brand
              <FaChevronDown />
            </button>

            {isBrandOpen && (
              <div className="absolute mt-2 bg-white border rounded-lg shadow-lg p-4 z-50">
                {availableBrands.map((brand) => (
                  <label key={brand} className="block">
                    <input
                      type="checkbox"
                      checked={selectedBrands.includes(brand)}
                      onChange={() => handleBrandToggle(brand)}
                    />{" "}
                    {brand}
                  </label>
                ))}
              </div>
            )}
          </div>

          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="border rounded-lg px-4 py-2"
          />

          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="border rounded-lg px-4 py-2"
          />
        </div>
      </div>

      {/* ================= CARD ================= */}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow p-6">
          <div className="flex items-center gap-3">
            <FaDollarSign />
            Total Penjualan
          </div>

          <h2 className="text-3xl font-bold mt-4 text-blue-600">
            {formatRupiah(totalSales)}
          </h2>
        </div>

        <div className="bg-white rounded-xl shadow p-6">
          <div className="flex items-center gap-3">
            <FaBox />
            Total Produk
          </div>

          <h2 className="text-3xl font-bold mt-4 text-green-600">{totalQty}</h2>
        </div>
      </div>

      {/* ================= GRAFIK ================= */}

      <div className="bg-white rounded-xl shadow p-6 mb-8">
        <h2 className="text-xl font-bold mb-5">Grafik Penjualan Bulanan</h2>

        <div
          style={{
            width: "100%",
            height: 350,
          }}
        >
          <ResponsiveContainer>
            <LineChart data={filteredChartData}>
              <CartesianGrid strokeDasharray="3 3" />

              <XAxis dataKey="bulan" />

              <YAxis tickFormatter={(v) => v / 1000 + "K"} />

              <Tooltip formatter={(value) => formatRupiah(value)} />

              <Line
                type="monotone"
                dataKey="total_penjualan"
                stroke="#2563eb"
                strokeWidth={3}
                dot={{ r: 5 }}
                activeDot={{ r: 8 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ================= TABEL ================= */}

      <div className="bg-white rounded-xl shadow p-6">
        <h2 className="text-xl font-bold mb-4">Data Penjualan</h2>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gray-100">
                <th className="border p-2">Tanggal</th>
                <th className="border p-2">Produk</th>
                <th className="border p-2">Toko</th>
                <th className="border p-2">Brand</th>
                <th className="border p-2">Wilayah</th>
                <th className="border p-2 text-right">Jumlah</th>
                <th className="border p-2 text-right">Total</th>
              </tr>
            </thead>

            <tbody>
              {filteredData.length === 0 ? (
                <tr>
                  <td colSpan="7" className="text-center border p-6">
                    Tidak ada data
                  </td>
                </tr>
              ) : (
                filteredData.map((item) => (
                  <tr key={item.id_penjualan} className="hover:bg-gray-50">
                    <td className="border p-2">{item.tanggal_penjualan}</td>

                    <td className="border p-2">{item.nama_produk}</td>

                    <td className="border p-2">{item.nama_toko}</td>

                    <td className="border p-2">{item.nama_brand}</td>

                    <td className="border p-2">{item.nama_wilayah}</td>

                    <td className="border p-2 text-right">{item.jumlah}</td>

                    <td className="border p-2 text-right">
                      {formatRupiah(item.total)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
