import {
  FaSignOutAlt,
  FaExclamationTriangle,
  FaArrowLeft,
} from "react-icons/fa";
import { useNavigate } from "react-router-dom";

export default function Logout() {
  const navigate = useNavigate();

  const handleLogout = () => {
    // Hapus data login
    localStorage.removeItem("user");
    localStorage.removeItem("role");
    localStorage.removeItem("nama");

    alert("Logout berhasil!");

    navigate("/login", { replace: true });
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
      <div className="w-full max-w-xl bg-white rounded-2xl shadow-lg border border-gray-100 p-8">

        {/* Icon */}
        <div className="w-20 h-20 mx-auto rounded-full bg-red-100 flex items-center justify-center text-red-500 text-4xl">
          <FaExclamationTriangle />
        </div>

        {/* Judul */}
        <div className="text-center mt-6">
          <h1 className="text-3xl font-bold text-gray-800">
            Keluar dari Sistem
          </h1>

          <p className="mt-3 text-gray-500">
            Apakah Anda yakin ingin keluar dari aplikasi HEBEPKU?
          </p>

          <p className="text-sm text-gray-400 mt-2">
            Pastikan semua data telah tersimpan sebelum mengakhiri sesi.
          </p>
        </div>

        {/* Tombol */}
        <div className="flex gap-4 mt-8">

          <button
            onClick={() => navigate(-1)}
            className="flex-1 py-3 border border-gray-300 rounded-xl text-gray-700 font-semibold hover:bg-gray-100 transition"
          >
            <div className="flex items-center justify-center gap-2">
              <FaArrowLeft />
              Batalkan
            </div>
          </button>

          <button
            onClick={handleLogout}
            className="flex-1 py-3 bg-red-500 hover:bg-red-600 text-white rounded-xl font-semibold transition"
          >
            <div className="flex items-center justify-center gap-2">
              <FaSignOutAlt />
              Logout
            </div>
          </button>

        </div>

        <p className="text-center text-xs text-gray-400 mt-8">
          © 2026 HEBEPKU
        </p>

      </div>
    </div>
  );
}