import { useEffect, useState } from "react";

export default function InputPenjualan() {

    const [brands, setBrands] = useState([]);
    const [kategori, setKategori] = useState([]);
    const [wilayah, setWilayah] = useState([]);

    const [formData, setFormData] = useState({
        id_brand: "",
        id_kategori: "",
        id_wilayah: "",
        id_user: JSON.parse(localStorage.getItem("user")).id_user,
        nama_produk: "",
        nama_toko: "",
        jumlah: "",
        total: "",
        tanggal_penjualan: "",
    });

    useEffect(() => {

        fetch("http://localhost:5000/api/brand")
            .then((res) => res.json())
            .then((result) => {
                if (result.success) {
                    setBrands(result.data);
                }
            });

        fetch("http://localhost:5000/api/kategori")
            .then((res) => res.json())
            .then((result) => {
                if (result.success) {
                    setKategori(result.data);
                }
            });

        fetch("http://localhost:5000/api/wilayah")
            .then((res) => res.json())
            .then((result) => {
                if (result.success) {
                    setWilayah(result.data);
                }
            });

    }, []);

    const handleChange = (e) => {

        setFormData({

            ...formData,

            [e.target.name]: e.target.value,

        });

    };

    const handleSubmit = async (e) => {

        e.preventDefault();

        try {

            const response = await fetch(
                "http://localhost:5000/api/penjualan",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify(formData),
                }
            );

            const result = await response.json();

            alert(result.message);

            if (result.success) {

                setFormData({
                    id_brand: "",
                    id_kategori: "",
                    id_wilayah: "",
                    id_user: 1,
                    nama_produk: "",
                    nama_toko: "",
                    jumlah: "",
                    total: "",
                    tanggal_penjualan: "",
                });

            }

        } catch (err) {

            console.log(err);

        }

    };

    return (

        <div className="p-8">

            <h1 className="text-3xl font-bold mb-6">

                Input Penjualan

            </h1>

            <form
                onSubmit={handleSubmit}
                className="bg-white rounded-xl shadow p-6 space-y-5"
            >

                <div className="grid grid-cols-2 gap-5">

                    <div>

                        <label>Brand</label>

                        <select
                            name="id_brand"
                            value={formData.id_brand}
                            onChange={handleChange}
                            className="border rounded-lg w-full p-2"
                            required
                        >

                            <option value="">Pilih Brand</option>

                            {brands.map((item) => (

                                <option
                                    key={item.id_brand}
                                    value={item.id_brand}
                                >

                                    {item.nama_brand}

                                </option>

                            ))}

                        </select>

                    </div>

                    <div>

                        <label>Kategori</label>

                        <select
                            name="id_kategori"
                            value={formData.id_kategori}
                            onChange={handleChange}
                            className="border rounded-lg w-full p-2"
                            required
                        >

                            <option value="">Pilih Kategori</option>

                            {kategori.map((item) => (

                                <option
                                    key={item.id_kategori}
                                    value={item.id_kategori}
                                >

                                    {item.nama_kategori}

                                </option>

                            ))}

                        </select>

                    </div>

                    <div>

                        <label>Wilayah</label>

                        <select
                            name="id_wilayah"
                            value={formData.id_wilayah}
                            onChange={handleChange}
                            className="border rounded-lg w-full p-2"
                            required
                        >

                            <option value="">Pilih Wilayah</option>

                            {wilayah.map((item) => (

                                <option
                                    key={item.id_wilayah}
                                    value={item.id_wilayah}
                                >

                                    {item.nama_wilayah}

                                </option>

                            ))}

                        </select>

                    </div>

                    <div>

                        <label>Nama Produk</label>

                        <input
                            type="text"
                            name="nama_produk"
                            value={formData.nama_produk}
                            onChange={handleChange}
                            className="border rounded-lg w-full p-2"
                            required
                        />

                    </div>

                    <div>

                        <label>Nama Toko</label>

                        <input
                            type="text"
                            name="nama_toko"
                            value={formData.nama_toko}
                            onChange={handleChange}
                            className="border rounded-lg w-full p-2"
                            required
                        />

                    </div>

                    <div>

                        <label>Jumlah</label>

                        <input
                            type="number"
                            name="jumlah"
                            value={formData.jumlah}
                            onChange={handleChange}
                            className="border rounded-lg w-full p-2"
                            required
                        />

                    </div>

                    <div>

                        <label>Total</label>

                        <input
                            type="number"
                            name="total"
                            value={formData.total}
                            onChange={handleChange}
                            className="border rounded-lg w-full p-2"
                            required
                        />

                    </div>

                    <div>

                        <label>Tanggal Penjualan</label>

                        <input
                            type="date"
                            name="tanggal_penjualan"
                            value={formData.tanggal_penjualan}
                            onChange={handleChange}
                            className="border rounded-lg w-full p-2"
                            required
                        />

                    </div>

                </div>

                <button
                    type="submit"
                    className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg"
                >

                    Simpan Penjualan

                </button>

            </form>

        </div>

    );

}