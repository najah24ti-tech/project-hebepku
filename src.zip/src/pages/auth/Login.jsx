import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import { BsFillExclamationDiamondFill } from "react-icons/bs";
import { ImSpinner2 } from "react-icons/im";

export default function Login() {
  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [dataForm, setDataForm] = useState({
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    setDataForm({
      ...dataForm,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setLoading(true);
    setError("");

    try {
      const response = await axios.post(
        "http://localhost:5000/api/auth/login",
        {
          email: dataForm.email,
          password: dataForm.password,
        }
      );

      if (response.data.success) {
        const user = response.data.user;

        // Simpan data user
        localStorage.setItem("user", JSON.stringify(user));
        localStorage.setItem("role", user.role);
        localStorage.setItem("nama", user.nama);

        // Redirect berdasarkan role
        switch (user.role) {
          case "owner":
            navigate("/dashboard");
            break;

          case "leader":
            navigate("/data-penjualan");
            break;

          case "ba":
            navigate("/input-penjualan");
            break;

          default:
            navigate("/dashboard");
            break;
        }
      } else {
        setError(response.data.message);
      }
    } catch (err) {
      console.error(err);

      if (err.response) {
        setError(err.response.data.message || "Login gagal");
      } else {
        setError("Server tidak dapat dihubungi");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4">
      <div className="w-full max-w-sm bg-white p-6 rounded-2xl shadow-lg">

        <div className="text-center mb-6">
          <h1 className="text-3xl font-bold">
            HEBEPKU<span className="text-green-500">.</span>
          </h1>

          <p className="text-gray-500 mt-2">
            Login Sistem
          </p>
        </div>

        {error && (
          <div className="flex items-center bg-red-100 border border-red-300 text-red-700 rounded-xl p-3 mb-4">
            <BsFillExclamationDiamondFill className="mr-2 text-lg" />
            <span>{error}</span>
          </div>
        )}

        {loading && (
          <div className="flex items-center bg-blue-100 border border-blue-300 text-blue-700 rounded-xl p-3 mb-4">
            <ImSpinner2 className="animate-spin mr-2 text-lg" />
            <span>Memproses...</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">

          <div>
            <label className="block mb-2 font-medium">
              Email
            </label>

            <input
              type="email"
              name="email"
              value={dataForm.email}
              onChange={handleChange}
              placeholder="Masukkan Email"
              className="w-full border border-gray-300 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-green-500"
              required
            />
          </div>

          <div>
            <label className="block mb-2 font-medium">
              Password
            </label>

            <input
              type="password"
              name="password"
              value={dataForm.password}
              onChange={handleChange}
              placeholder="********"
              className="w-full border border-gray-300 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-green-500"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className={`w-full py-3 rounded-xl font-semibold text-white transition ${
              loading
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-green-500 hover:bg-green-600"
            }`}
          >
            {loading ? "Loading..." : "Login"}
          </button>

        </form>

        <div className="mt-5 text-center">
          <p className="text-sm text-gray-600">
            Belum memiliki akun?
          </p>

          <Link
            to="/register"
            className="mt-3 inline-block w-full py-3 border-2 border-green-500 text-green-500 font-semibold rounded-xl hover:bg-green-500 hover:text-white transition duration-300"
          >
            Register
          </Link>
        </div>

        <p className="text-center text-xs text-gray-400 mt-6">
          © 2026 HEBEPKU
        </p>

      </div>
    </div>
  );
}