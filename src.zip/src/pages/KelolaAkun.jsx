import { useState, useEffect } from "react";
import PageHeader from "../components/PageHeader";
import {
  FaUserPlus,
  FaEdit,
  FaTrashAlt,
  FaUserShield,
  FaUserTag,
  FaUsers,
} from "react-icons/fa";

export default function KelolaAkun() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    getUsers();
  }, []);

  const [showModal, setShowModal] = useState(false);

  const [formData, setFormData] = useState({
    nama: "",
    email: "",
    password: "",
    role: "ba",
    is_active: 1,
  });
  const [editId, setEditId] = useState(null);

  const handleEdit = (user) => {
    setEditId(user.id_user);

    setFormData({
      nama: user.nama,
      email: user.email,
      password: "",
      role: user.role,
      is_active: user.is_active,
    });

    setShowModal(true);
  };

  const handleDelete = async (user) => {
    if (!window.confirm(`Yakin hapus ${user.nama}?`)) return;

    try {
      const url = editId
        ? `http://localhost:5000/api/users/${editId}`
        : "http://localhost:5000/api/users";

      const method = editId ? "PUT" : "POST";

      const response = await fetch(url, {
        method,

        method: "DELETE",
      });

      const result = await response.json();

      if (result.success) {
        setUsers(users.filter((u) => u.id_user !== user.id_user));
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const getUsers = async () => {
    try {
      const response = await fetch("http://localhost:5000/api/users");

      const result = await response.json();

      if (result.success) {
        setUsers(result.data);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const url = editId
        ? `http://localhost:5000/api/users/${editId}`
        : "http://localhost:5000/api/users";

      const method = editId ? "PUT" : "POST";

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const result = await response.json();

      alert(result.message);

      if (result.success) {
        setShowModal(false);
        setEditId(null);

        setFormData({
          nama: "",
          email: "",
          password: "",
          role: "ba",
          is_active: 1,
        });

        getUsers();
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="bg-gray-50 min-h-screen space-y-2">
      {" "}
      {/* SECTION TOP: Title & PageHeader */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
            <FaUsers className="text-blue-600" /> Kelola Akun
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Manajemen data pengguna sistem dan pengaturan hak akses.
          </p>
        </div>
        {/* <PageHeader /> */}
      </div>
      {/* SECTION ACTION: Tambah User */}
      <div className="flex justify-end">
        <button
          onClick={() => setShowModal(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 px-5 rounded-xl shadow-lg shadow-blue-200 transition-all flex items-center gap-2 active:scale-95"
        >
          <FaUserPlus /> Tambah User Baru
        </button>
      </div>
      {/* SECTION TABLE */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-100">
            <thead>
              <tr className="bg-gray-50/50">
                <th className="px-6 py-4 text-left text-xs font-bold text-gray-400 uppercase tracking-wider">
                  Nama Pengguna
                </th>
                <th className="px-6 py-4 text-left text-xs font-bold text-gray-400 uppercase tracking-wider">
                  Email
                </th>
                <th className="px-6 py-4 text-left text-xs font-bold text-gray-400 uppercase tracking-wider">
                  Role
                </th>
                <th className="px-6 py-4 text-left text-xs font-bold text-gray-400 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-4 text-center text-xs font-bold text-gray-400 uppercase tracking-wider">
                  Aksi
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {users.map((user) => (
                <tr
                  key={user.id_user}
                  className="hover:bg-blue-50/30 transition-colors group"
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-xs">
                        {user.nama.charAt(0)}
                      </div>
                      <span className="text-sm font-semibold text-gray-800">
                        {user.nama}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {user.email}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5 text-sm text-gray-700">
                      {user.role === "owner" ? (
                        <FaUserShield className="text-amber-500" />
                      ) : (
                        <FaUserTag className="text-gray-400" />
                      )}

                      {user.role === "owner"
                        ? "Owner"
                        : user.role === "leader"
                          ? "Leader"
                          : "BA"}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-3 py-1 text-[10px] font-bold uppercase tracking-wider rounded-full ${
                        user.is_active == 1
                          ? "bg-green-100 text-green-700"
                          : "bg-red-100 text-red-700"
                      }`}
                    >
                      {user.is_active == 1 ? "Aktif" : "Nonaktif"}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm">
                    <div className="flex justify-center gap-2">
                      <button
                        onClick={() => handleEdit(user)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Edit User"
                      >
                        <FaEdit />
                      </button>
                      <button
                        onClick={() => handleDelete(user)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Hapus User"
                      >
                        <FaTrashAlt />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* FOOTER TABLE: Info & Pagination */}
        <div className="bg-gray-50/50 px-6 py-4 flex flex-col md:flex-row justify-between items-center gap-4 border-t border-gray-100">
          <span className="text-xs text-gray-500">
            Menampilkan{" "}
            <span className="font-bold text-gray-700">{users.length}</span> dari{" "}
            <span className="font-bold text-gray-700">{users.length}</span> user
          </span>
          <div className="flex gap-2">
            <button className="px-3 py-1 border rounded-md text-xs bg-white text-gray-400 cursor-not-allowed">
              Previous
            </button>
            <button className="px-3 py-1 border rounded-md text-xs bg-blue-600 text-white font-bold">
              1
            </button>
            <button className="px-3 py-1 border rounded-md text-xs bg-white text-gray-600 hover:bg-gray-50">
              2
            </button>
            <button className="px-3 py-1 border rounded-md text-xs bg-white text-gray-600 hover:bg-gray-50">
              Next
            </button>
          </div>
        </div>
      </div>
      {/* MODAL TAMBAH USER */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg p-6">
            {editId ? "Edit User" : "Tambah User"}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-sm font-medium">Nama</label>

                <input
                  type="text"
                  name="nama"
                  value={formData.nama}
                  onChange={handleChange}
                  required
                  className="w-full mt-1 border rounded-lg px-3 py-2"
                />
              </div>

              <div>
                <label className="text-sm font-medium">Email</label>

                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full mt-1 border rounded-lg px-3 py-2"
                />
              </div>

              <div>
                <label className="text-sm font-medium">Password</label>

                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder={
                    editId
                      ? "Kosongkan jika tidak ingin mengubah password"
                      : "Masukkan password"
                  }
                  required={!editId}
                  className="w-full mt-1 border rounded-lg px-3 py-2"
                />

                {editId && <p className="text-xs text-gray-500 mt-1"></p>}
              </div>

              <div>
                <label className="text-sm font-medium">Role</label>

                <select
                  name="role"
                  value={formData.role}
                  onChange={handleChange}
                  className="w-full mt-1 border rounded-lg px-3 py-2"
                >
                  <option value="owner">Owner</option>
                  <option value="leader">Leader</option>
                  <option value="ba">BA</option>
                </select>
              </div>

              <div>
                <label className="text-sm font-medium">Status</label>

                <select
                  name="is_active"
                  value={formData.is_active}
                  onChange={handleChange}
                  className="w-full mt-1 border rounded-lg px-3 py-2"
                >
                  <option value={1}>Aktif</option>
                  <option value={0}>Nonaktif</option>
                </select>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-lg border"
                >
                  Batal
                </button>

                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 text-white rounded-lg"
                >
                  {editId ? "Update" : "Simpan"}{" "}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
