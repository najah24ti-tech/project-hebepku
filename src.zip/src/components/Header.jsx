import React from "react";
import { FaChevronDown } from "react-icons/fa";

export default function Header() {
  return (
    <div className="w-full bg-[#F5D5D5] rounded-2xl px-8 py-7 shadow-sm mb-6 flex flex-col justify-between min-h-[140px] relative">
      
      {/* Baris Atas: Judul & Profil Card (Sejajar Sisi Kanan-Kiri) */}
      <div className="flex justify-between items-start w-full">
        {/* Judul Utama */}
        <h1 className="text-2xl md:text-2xl font-bold text-gray-900 tracking-tight">
          Selamat Datang Owner, Widodo
        </h1>

        {/* Tombol Profil Pengguna (Sisi Kanan Sesuai Image_6d8bf3) */}
        <div className="flex items-center gap-2.5 bg-white px-4 py-2 rounded-xl shadow-sm cursor-pointer hover:bg-gray-50 transition-all select-none self-center">
          {/* Lingkaran Placeholder Foto */}
          <div className="w-6 h-6 rounded-full bg-[#FCEFEE] flex items-center justify-center">
            <img 
              src="https://avatar.iran.liara.run/public/28" 
              className="w-full h-full rounded-full object-cover" 
              alt="Widodo Avatar" 
            />
          </div>
          {/* Nama & Tanda Dropdown */}
          <span className="text-xs font-semibold text-gray-700 tracking-wide">
            Widodo Owner
          </span>
          <FaChevronDown className="text-[10px] text-gray-400" />
        </div>
      </div>

      {/* Baris Bawah: Deskripsi/Sub-judul (Berada di Dasar Banner Sesuai Image_6d8bf3) */}
      <div className="mt-6">
        <p className="text-xs md:text-sm text-gray-600 font-medium tracking-wide">
          Pantau performa penjualan skincare secara real-time.
        </p>
      </div>

    </div>
  );
}