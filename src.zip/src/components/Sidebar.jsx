import { AiOutlineUser } from "react-icons/ai";
import { FiLogOut } from "react-icons/fi";
import { RxDashboard } from "react-icons/rx";
import { NavLink } from "react-router-dom";
import { FaClipboardList } from "react-icons/fa";

export default function Sidebar() {
  const role = localStorage.getItem("role");

  const menuClass = ({ isActive }) =>
    `flex items-center rounded-xl p-4 font-medium transition-all ${
      isActive
        ? "bg-green-200 text-hijau font-extrabold"
        : "text-gray-600 hover:bg-green-200 hover:text-hijau"
    }`;

  return (
    <div className="flex min-h-screen w-80 flex-col bg-white p-8 shadow-lg">
      {/* Logo */}
      <div>
        <h1 className="text-5xl font-bold">
          HEBEPKU<span className="text-hijau">.</span>
        </h1>

        <p className="text-gray-400 font-medium">Modern Admin Dashboard</p>
      </div>

      {/* Menu */}
      <div className="mt-10">
        <ul className="space-y-3">
          {/* Dashboard */}
          <li>
            <NavLink
              to={
                role === "owner"
                  ? "/dashboard"
                  : role === "leader"
                    ? "/data-penjualan"
                    : "/input-penjualan"
              }
              className={menuClass}
            >
              <RxDashboard className="mr-4 text-xl" />
              Dashboard
            </NavLink>
          </li>

          {/* Owner */}
          {role === "owner" && (
            <li>
              <NavLink to="/kelola-akun" className={menuClass}>
                <AiOutlineUser className="mr-4 text-xl" />
                Kelola Akun
              </NavLink>
            </li>
          )}

          {/* Leader */}
          {role === "leader" && (
            <li>
              <NavLink to="/data-penjualan" className={menuClass}>
                <FaClipboardList className="mr-4 text-xl" />
                Data Penjualan
              </NavLink>
            </li>
          )}

          {/* BA */}
          {role === "ba" && (
            <li>
              <NavLink to="/input-penjualan" className={menuClass}>
                <FaClipboardList className="mr-4 text-xl" />
                Input Penjualan
              </NavLink>
            </li>
          )}

          {/* Logout */}
          <li>
            <NavLink to="/logout" className={menuClass}>
              <FiLogOut className="mr-4 text-xl" />
              Logout
            </NavLink>
          </li>
        </ul>
      </div>

      {/* Footer */}
      <div className="mt-auto pt-8 border-t">
        <div className="flex items-center gap-3">
          <img
            src="https://avatar.iran.liara.run/public/28"
            alt="User"
            className="w-12 h-12 rounded-full"
          />

          <div>
            <h3 className="font-semibold text-gray-700">HEBEPKU</h3>

            <p className="text-xs text-gray-400">Sales Management System</p>
          </div>
        </div>

        <div className="mt-6 text-xs text-gray-400">© 2026 HEBEPKU</div>
      </div>
    </div>
  );
}
