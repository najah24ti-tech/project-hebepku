import React, { Suspense } from "react";
import { Route, Routes, Navigate } from "react-router-dom";
import Loading from "./components/Loading";
import "./assets/tailwind.css";

const MainLayout = React.lazy(() => import("./layouts/MainLayout"));
const AuthLayout = React.lazy(() => import("./layouts/AuthLayout"));

const Dashboard = React.lazy(() => import("./pages/Dashboard"));
const DataPenjualan = React.lazy(() => import("./pages/DataPenjualan"));
const InputPenjualan = React.lazy(() => import("./pages/InputPenjualan"));
const KelolaAkun = React.lazy(() => import("./pages/KelolaAkun"));
const Logout = React.lazy(() => import("./pages/Logout"));
const NotFound = React.lazy(() => import("./pages/NotFound"));

const Login = React.lazy(() => import("./pages/auth/Login"));
const Register = React.lazy(() => import("./pages/auth/Register"));
const Forgot = React.lazy(() => import("./pages/auth/Forgot"));

export default function App() {
  return (
    <Suspense fallback={<Loading />}>
      <Routes>
        {/* Saat pertama membuka aplikasi langsung ke Login */}
        <Route path="/" element={<Navigate to="/login" replace />} />

        {/* Halaman Authentication */}
        <Route element={<AuthLayout />}>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/forgot" element={<Forgot />} />
        </Route>

        {/* Halaman Setelah Login */}
        <Route element={<MainLayout />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/kelola-akun" element={<KelolaAkun />} />
          <Route path="/data-penjualan" element={<DataPenjualan />} />
          <Route path="/input-penjualan" element={<InputPenjualan />} />
          <Route path="/logout" element={<Logout />} />
        </Route>

        {/* Halaman Tidak Ditemukan */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  );
}
